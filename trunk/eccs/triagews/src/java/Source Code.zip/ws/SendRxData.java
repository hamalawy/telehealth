/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ws;

import javax.jws.*;
import java.sql.*;

/**
 *
 * @author User
 */
@WebService(
            name = "SendR",
            serviceName = "SendRxDataService",
            portName = "SendRxDataPort")
public class SendRxData {
    
    private String errormsg = "";
    private String hasNullValue;
    private boolean newmsg = false;
    private String timestamp;

    private DocUser doctor = new DocUser();
    
    public static Date getCurrentJavaSqlDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
    
    public boolean hasNullValue(String userkey, String patientid, String firstname, String middlename, 
            String lastname, String sex, int age, String agevalidity, String location) 
    {
        if (userkey.equals("")) {
            hasNullValue = "userkey";
            return true;
        }
        if (patientid.equals("")) {
            hasNullValue = "patientid";
            return true;
        }
        if (firstname.equals("")) {
            hasNullValue = "firstname";
            return true;
        }
        if (middlename.equals("")) {
            hasNullValue = "middlename";
            return true;
        }
        if (lastname.equals("")) {
            hasNullValue = "lastname";
            return true;
        }
        if (sex.equals("")) {
            hasNullValue = "sex";
            return true;
        }
        if (agevalidity.equals("")) {
            hasNullValue = "agevalidity";
            return true;
        }
        if (location.equals("")) {
            hasNullValue = "location";
            return true;
        }
        
        return false;
    }
  
    @WebMethod
    public boolean newCreatemsg() {
        return this.newmsg;
    }
    
    @WebMethod
    public String getCreatemsg() {
        
        String message;
        
        message = this.errormsg;
        
        this.errormsg = "";
        
        this.newmsg = false;
        
        return message;
    }
    
    @WebMethod
    public boolean sendRxData(@WebParam(name="userkey") String userkey, @WebParam(name="dataid") String dataid, @WebParam(name="referralid") String referralid, 
            @WebParam(name="ECGtime") String ecgtime, @WebParam(name="ECGy") String ecgy, @WebParam(name="bloodox") double bloodox, @WebParam(name="bpressure") double bpressure,
            @WebParam(name="heartrate") double heartrate)
    {        
        
 /*       if (!doctor.DocLoggedIn()) {
            this.errormsg = "ACCESS DENIED: PLEASE LOG-IN FIRST.";
            System.out.println(errormsg);
            return false;
        }
    
    String status = "saved";
    String referrer = this.doctor.getUser();
  
  */
    
    boolean toReturn = true;
    SqlNet connect = new SqlNet();
    
  /*      if (hasNullValue(userkey, patientid, firstname, middlename, lastname, sex, age, agevalidity, location)) {
            errormsg = new String("CREATE PATIENT ERROR: Please Fill-Out the REQUIRED Field " + hasNullValue + ".");
            System.err.println(errormsg);
            newmsg = true;
            return false;
        }*/
   /*     long timestamp = ecgtime[1] * 1000;  // msec
        java.util.Date d = new java.util.Date(timestamp);
        java.sql.Date time = new java.sql.Date(d.getTime());*/

        String sql = new String("INSERT INTO triage.rxdata" +
                 "(dataid, referralid, ecgtime, ecgy, bloodox, bpressure, heartrate ) " +
                 "VALUES ('" + dataid + "', '" + referralid + "', '" +
                 ecgtime + "', '" + ecgy + "', '" + bloodox + "', '" +
                 bpressure + "', '" + heartrate + "');");
        
        connect.queryUpdate(sql);
        return toReturn;
      
    }
    
}
