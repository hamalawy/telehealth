/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ws;

/**
 *
 * @author Pepz
 */
public class Patient {
    
    String patientid;
    String firstname;
    String middlename;
    String lastname;
    String maidenname;
    String sex;
    java.util.Date birthdate;
    int age;
    String agevalidity;
    String location;
    
}
