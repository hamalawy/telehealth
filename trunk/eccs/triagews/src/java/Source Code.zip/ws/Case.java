/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ws;

/**
 *
 * @author Pepz
 */
public class Case {
    
    String referralid;
    String description;
    String reason;
    String patientid;
    java.util.Date timestamp;
    String institutionid;
    String docname;
    String docnum;
    String status;
    
}
